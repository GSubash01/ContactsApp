# contactapp
A simple android application to save contact
